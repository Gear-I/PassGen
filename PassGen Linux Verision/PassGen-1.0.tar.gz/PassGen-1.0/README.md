PassGen

This PassGen will help people keep their accounts secured and help reduce password breaches. This tool generates and stores passwords into a database. In addition, this tool can be used on windows and Linux operating system, by installing EXE file.
